# Shadow Estimator — Grok Bot import

This zip is a complete, credential-free copy of the **shadow-estimator** project
(Next.js 14 electrical takeoff + estimate app).

## Import on the receiving Grok Bot

Paste this to the other Grok Bot after attaching the zip:

> Unzip `shadow-estimator-grok-bot-import.zip` into `/workspace/shadow-estimator`.
> Treat that folder as the full project. Read `AGENTS.md` and `GROK_BOT_IMPORT.md`.
> Do not look for `.git` history or secrets in this archive.

If the zip is already on the computer:

```bash
mkdir -p /workspace
unzip -o shadow-estimator-grok-bot-import.zip -d /tmp/shadow-estimator-unpack
rm -rf /workspace/shadow-estimator
mv /tmp/shadow-estimator-unpack/shadow-estimator /workspace/shadow-estimator
cd /workspace/shadow-estimator
```

After unzip, the project root is `/workspace/shadow-estimator`.

## Bootstrap

```bash
cd /workspace/shadow-estimator
npm ci
```

PDF takeoff needs system binaries:

```bash
sudo apt-get update
sudo apt-get install -y poppler-utils imagemagick
```

Optional AI scan features (autoscan / smart-scan / OCR inventory) need:

```bash
# create locally; do not commit
echo 'GEMINI_API_KEY=your_key_here' > .env.local
```

The catalog, takeoff UI, and estimate math work without that key.

## Run

```bash
npm run build
npm run start
```

App listens on `http://localhost:3001` (`next start -p 3001 -H 0.0.0.0`).

Dev mode: `npm run dev` (default Next port 3000 unless you override it).

Lint: `npm run lint`

## What this archive contains

- `src/` — App Router pages, takeoff/estimate UI, API routes, catalog
- `public/` — electrical catalog JSON, sample plan PDFs
- `scripts/` — electrical catalog builder and scan tests
- `AGENTS.md` — project notes for agents
- `Dockerfile` — Node 20 + Poppler + ImageMagick production image
- `package.json` / `package-lock.json`

## What this archive does not contain

- `.git` (no remotes, tokens, or history)
- `node_modules/`, `.next/`, `.env*`
- API keys

## Catalog

Source of truth: `scripts/build-electrical-catalog.py`

```bash
python3 scripts/build-electrical-catalog.py
```

Output: `public/data/catalog.json`

## Sample plans

- `/test-plan.pdf` and `/test-electrical-plan.pdf` — electrical takeoff samples
- Additional sample PDFs live under `public/`
